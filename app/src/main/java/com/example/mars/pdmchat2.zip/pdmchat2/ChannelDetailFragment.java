package com.example.mars.pdmchat2;

import android.app.Activity;
import android.support.design.widget.CollapsingToolbarLayout;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.mars.pdmchat2.Models.OpenChannel;
import com.example.mars.pdmchat2.Services.APIService;

import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * A fragment representing a single Channel detail screen.
 * This fragment is either contained in a {@link ChannelListActivity}
 * in two-pane mode (on tablets) or a {@link ChannelDetailActivity}
 * on handsets.
 */
public class ChannelDetailFragment extends Fragment {
    /**
     * The fragment argument representing the item ID that this fragment
     * represents.
     */
    public static final String ARG_ITEM_ID = "item_id";

    /**
     * The dummy content this fragment is presenting.
     */
    private OpenChannel mItem;
    final APIService apiService;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public ChannelDetailFragment() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.sendbird.com/v3/")
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();

        // create an instance of the ApiService
        apiService = retrofit.create(APIService.class);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final ChannelDetailFragment THIS = this;

        if (getArguments().containsKey(ARG_ITEM_ID)) {
            // Load the dummy content specified by the fragment
            // arguments. In a real-world scenario, use a Loader
            // to load content from a content provider.
            Single<OpenChannel> openChannelSubscription = apiService.getOpenChannelData(getArguments().getString(ARG_ITEM_ID));
            openChannelSubscription.subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new SingleObserver<OpenChannel>() {
                        @Override
                        public void onSubscribe(Disposable d) {}
                        @Override
                        public void onSuccess(OpenChannel openChannel) {
                            mItem = openChannel;
                            Activity activity = THIS.getActivity();
                            CollapsingToolbarLayout appBarLayout = (CollapsingToolbarLayout) activity.findViewById(R.id.toolbar_layout);
                            if (appBarLayout != null) {
                                appBarLayout.setTitle(mItem.getName());
                            }
                        }
                        @Override
                        public void onError(Throwable e) {}
                    });
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.channel_detail, container, false);

        // Show the dummy content as text in a TextView.
        Single<OpenChannel> openChannelSubscription = apiService.getOpenChannelData(getArguments().getString(ARG_ITEM_ID));
        openChannelSubscription.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<OpenChannel>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        System.out.println("connected");
                    }
                    @Override
                    public void onSuccess(OpenChannel openChannel) {
                        mItem = openChannel;
                        System.out.println(mItem.getCustomType());
                        ((TextView) rootView.findViewById(R.id.channel_detail)).setText(mItem.getCustomType());
                    }
                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                    }
                });

        return rootView;
    }
}
